<div class="">
    <div class="shimmer w-[94px] h-[38px] rounded-md"></div>
</div>
