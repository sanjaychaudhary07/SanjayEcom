<td {{ $attributes->merge(['scope' => 'row', 'class' => 'whitespace-nowrap px-6 py-4 dark:bg-gray-800 text-gray-600 dark:text-gray-300']) }}>
    {{ $slot }}
</td>
