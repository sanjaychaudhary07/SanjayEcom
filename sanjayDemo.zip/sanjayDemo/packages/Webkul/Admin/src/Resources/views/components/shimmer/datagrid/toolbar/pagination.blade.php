<div class="flex items-center gap-x-2">
    <div class="shimmer w-[72px] h-[38px] rounded-md"></div>

    <p class="shimmer w-14 h-6"></p>

    <div class="shimmer w-10 h-[38px] rounded-md"></div>

    <div class="shimmer w-[37px] h-6"></div>

    <div class="flex items-center gap-1">
        <div class="shimmer w-[38px] h-[38px] rounded-md"></div>

        <div class="shimmer w-[38px] h-[38px] rounded-md"></div>
    </div>
</div>
